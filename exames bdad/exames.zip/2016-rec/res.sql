.mode columns
.headers ON

/* 1. */