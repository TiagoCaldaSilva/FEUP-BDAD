.mode columns
.headers ON

